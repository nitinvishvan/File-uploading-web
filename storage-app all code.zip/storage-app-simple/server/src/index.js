import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import filesRouter from './routes/files.js';

dotenv.config();
const app = express();

app.use(cors({ origin: '*' }));
app.use(express.json());

app.use('/api/files', filesRouter);

const port = process.env.PORT || 8080;
app.listen(port, () => console.log(`Server running on http://localhost:${port}`));
