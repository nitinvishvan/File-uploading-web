import React, { useState, useEffect } from 'react';
import { createRoot } from 'react-dom/client';
import axios from 'axios';

function App() {
  const [files, setFiles] = useState([]);
  const [selected, setSelected] = useState(null);

  useEffect(() => { load(); }, []);

  async function load() {
    const res = await axios.get('http://localhost:8080/api/files/list');
    setFiles(res.data);
  }

  async function upload(e) {
    const data = new FormData();
    data.append('file', e.target.files[0]);
    await axios.post('http://localhost:8080/api/files/upload', data);
    load();
  }

  return (
    <div style={{ padding: 20 }}>
      <h1>Free Storage App</h1>
      <input type="file" onChange={upload} />
      <ul>
        {files.map(f => (
          <li key={f}>
            {f} - <a href={`http://localhost:8080/api/files/download/${f}`} download>Download</a>
          </li>
        ))}
      </ul>
    </div>
  );
}

createRoot(document.getElementById('root')).render(<App />);
